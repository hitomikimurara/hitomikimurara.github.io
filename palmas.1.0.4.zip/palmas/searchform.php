<form method="get" class="searchform search-form" action="<?php echo esc_url( home_url( '/' ) ); ?>">
	<fieldset> 
		<input type="text" name="s" class="s" value="" placeholder="Search here"> 
		<button class="fa fa-search search-button" type="submit" value="Search"></button>
	</fieldset>
</form>