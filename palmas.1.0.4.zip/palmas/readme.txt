
== Description ==

Palmas is free WordPress theme

Palmas WordPress Theme, Copyright 2016 WPKube
Palmas is distributed under the GNU General Public License, version 2

== JS Files ==

Modernizr: MIT License
https://modernizr.com/license/

FlexSlider: GPL v2
https://github.com/woothemes/FlexSlider/blob/master/LICENSE.md

Select2: MIT License
https://github.com/select2/select2/blob/master/LICENSE.md

FitVids 1.1
https://github.com/davatron5000/FitVids.js

== Fonts ==
Font Awesome: MIT and GPL licenses
http://fontawesome.io/license/
